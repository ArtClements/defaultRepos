package clements5;
//Arthur Clements, SPC ID 00002405071
//Create a program that prints out a list of temperatures with the range of -40f
//through 120f convert the temperature to celcius and display the temperatures on one row,
//then moving to the next to display the next set of temps, incrementing the F temp by 5
//degrees each time. print out the temp with precision of 2 decimal places.
public class TemperatureChart {

	public static void main(String[] args) {
		System.out.printf("%-11s|%10s\n", "Farenheit", "Celsius");
		// loop that iterates through farenheit from -40 to 120, incrementing by 5 each time.
		for(double farenheit=-40; farenheit<=120; farenheit+=5){
			double celcius = ((farenheit - 32)*5)/9;
			// convert the temp in farenheit to celcius and the print out the two temps
			System.out.printf("%-10.2f |%10.2f\n", farenheit, celcius);
		}
	}
}