package clements7and11;
// Arthur Clements, SPC ID 00002405071
// Create an ArrayList of strings to store the names of celebrities or athletes. Add five names to the list.
// Process the list with a for loop and the get() method to display the names, one name per line. Pass the list to a void method.
// Inside the method, Insert another name at index 2 and remove the name at index 4. Use a foreach loop to display the ArrayList again, 
// all names on one line separated by asterisks. After the method call in main, create an iterator for the ArrayList and use it to 
// display the list one more time.

import java.util.*;
public class ArrayListNames {
	
	public static void main(String[] args) {
		// create list to store athlete names
		ArrayList<String> athletes = new ArrayList<>();
		// add names to the ArrayList
		athletes.add("Alex Killorn");
		athletes.add("Brayden Point");
		athletes.add("Nakita Kucherov");
		athletes.add("Steven Stamkos");
		athletes.add("Victor Headman");
		
		System.out.println("Here is the list of the Lightning's power play top line:");
		// print the initial list using a foreach loop
		for (int i = 0; i< athletes.size(); i++) {
			System.out.println(athletes.get(i) + " ");
		}
		
		System.out.println();
		// call the updateList method, passing the ArrayList athletes
		updateList(athletes);
		System.out.println();
		
		System.out.println("Using an iterator, here is the list:");
		// create iterator to output the items in the ArrayList
		Iterator<String> iterator = athletes.iterator();
		// while loop to print the names while there are items left
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	//method to update list
	public static void updateList(ArrayList<String> athleteNames) {
		// add new name to element 2 in the ArrayList
		athleteNames.add(2,"Anthony Cirelli");
		// remove element 4 from the ArrayList
		athleteNames.remove(4);
		System.out.println("Now the line up is ");
		// for each loop to output the new list with an * between each.
		for(String n: athleteNames){
			System.out.print(n + " * ");
		}
		System.out.println();
	}
}