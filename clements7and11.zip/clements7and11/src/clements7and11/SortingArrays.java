package clements7and11;
// Arthur Clements, SPC ID 00002405071
// declare an array to hold eight integers. use a for loop to add eight random integers, all in the range from 50 to 100, inclusive, to the array. 
// Duplicates are okay. Next, pass the array to a method that sorts the array and returns another array containing only the largest and smallest 
// elements in the original array. Print these two values in main. Then use a foreach loop to display all elements of the sorted array on one line
// separated by a single space. This latter loop should also count the odd and even numbers in the array and determine the sum of all elements in the array.

import java.util.Arrays;
public class SortingArrays {

	public static void main(String[] args) {
		// create a new array containing 8 elements
		int[] numbers = new int[8];
		// variables to hold the sum of the elements and the amount of evens and the amount of odds
		int sum = 0;
		int evens = 0;
		int odds = 0;
		// use a for loop to add 8 ints from 50-100 to the array
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = 50 + (int)(Math.random()*51);
		}
		// create 2 character array to hold the low and high elements, and passing them to the method used to sort the array.
		int[] minMax = sortArray(numbers);
		// display the low element
		System.out.println("The lowest element is: " + minMax[0]);
		// display the highest element
		System.out.println("The highest element is: " + minMax[1]);
		System.out.println("Here is the array: ");
		// use a foreach to display the numbers,
		for (int n: numbers) {
			System.out.print(n + " ");
			// add the value of the current element to sum
			sum += n;
			// use if statement to determine if the element is even or odd, incrementing the correct variable.
			if(n % 2 == 0) {
				evens++;
			}
			else
				odds++;
		}
		//output the amount of even and odds
		System.out.println();
		System.out.println("The array contains " + evens + " evens and " + odds + " odds");
		System.out.println("The Arrays total is: " + sum);
	}	
	// method used to sort the array and then to assign the 2 element array to return to main containing the lowest and highest items.
	public static int[] sortArray(int[] list) {
		// declare an array to hold the 2 elements
		int[] minMax = new int [2];
		// sort the array from smallest to largest using the arrays class and assign the first (smallest) and last (largest) items to 
		// the first and second index (o and 1) of the minMax array
		Arrays.sort(list);
		minMax [0] = list[0];
		minMax [1] = list[list.length-1];
		// return the 2 element array
		return minMax;
		}
}