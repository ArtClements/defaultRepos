package clements7and11;
// Arthur Clements, SPC ID 00002405071
// Write a method named sumInts that can take a variable number of int arguments and return the sum of these arguments.
// The ints to be summed up must be entered as command line arguments. In the main method, display the ints that were 
// entered on the command line then execute sumInts and display the sum it returns.

import java.util.Arrays;
public class CommandLineArguments {
	
	public static void main(String[] args) {
		// print the array using the .toString method in the arrays class
		System.out.println("Passing: " + Arrays.toString(args));
		System.out.println();
		// print the sum of the command line arguments, calling the sumInts method, passing it the array of command line arguments
		System.out.println("The sume is " + sumInts(args));
	}
	// sumInts method
	public static int sumInts(String[] args) {
		// variable to hold sum
		int sum = 0;
		// for loop to add to sum using the length of the array thast was passed
		for (int i = 0; i < args.length; i++) {
			// add the current element to sum after parsing it to an int.
			sum += Integer.parseInt(args[i]);
		}
		// return sum
		return sum;
	}
}