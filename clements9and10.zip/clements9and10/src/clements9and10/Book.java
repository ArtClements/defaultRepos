package clements9and10;
// Arthur Clements, SPC ID 00002405071
// Create a class Book and executable class named testBook
// has instance data members (all private) String title, String author, int pages, double price.
// has a public static int variable named numBooks with an initial value of zero.
// has a parameterized constructor that will be used to make a Book object and assign values to its data members, and increment numBooks.
// has a no-arg constructor that increments numBooks.
// has getters and setters for all instance data members.
// has a toString() method that returns a string displaying the state of a Book instance.
// Use the numBooks variable to report the number of books instantiated.

public class Book {
	// Private data members to hold title, author, price and pages as well as an numBooks to hold the total amount of book objects we create
	private String title;
	private String author;
	private double price;
	private int pages;
	public  static int numBooks = 0;
	
	// Create a constructor that takes parameters
	public Book(String title, String author, int pages, double price){
		this.title = title;
		this.author = author;
		this.pages = pages;
		this.price = price;
		numBooks++;
	}
	// Create a no-arg constructor.
	public Book() {
		numBooks++;
	}
	
	//create getters
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public double getPrice() {
		return price;
	}
	public int getPages() {
		return pages;
	}
	// create setters
	public void setTitle(String title) {
		this.title = title;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	// to string method to output object info
	@Override
	public String toString() {
		return String.format("Book title= " + title + ", Author= " + author + ", Pages= " + pages + " Price= $" + (double)Math.round(price*100d)/100d);
	}
	
}
