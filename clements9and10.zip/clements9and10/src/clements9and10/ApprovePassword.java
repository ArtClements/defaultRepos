package clements9and10;
// Arthur Clements, SPC ID 00002405071
// Write a Java program that prompts the user to enter a password that matches a specific pattern.
// Your program must approve the user's entry. Here is the pattern, in this order:
// 1 or more upper case letters
// two lower case letters
// 1 or 2 digits
// zero or 1 upper case letters
// any two of this group @#$%^&

import java.util.*;

public class ApprovePassword {
	public static void main(String[] args) {
		boolean invalid = true;
		// Create scanner
		Scanner input = new Scanner(System.in);
		while(invalid) {
		// Prompt user for password
		System.out.println("Please input a valid password that meets the following criteria:\r"
				+ "\r1 or more upper case letters\r"
				+ "Two lower case letters\r"
				+ "1 or 2 digits\r"
				+ "Zero or 1 upper case letters\r"
				+ "Any two of this group of characters: @#$%^&\r"
				+ "\rYour password: ");
		// Store password:
		String password = input.next();
		// test the entered password stepping through with regex syntax
		if(password.matches("[A-Z]+[a-z]{2}\\d{1,2}[A-Z]?[@#$%^&]{2}")) {
			// if valid advise
			System.out.println("Valid password input");
			invalid = false;
			break;
		}
		else
			// advise if invalid
			System.out.println("Invalid password input\r");
			invalid = true;
		}
		input.close();
	}
}