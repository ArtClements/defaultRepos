package clements9and10;
// Arthur Clements, SPC ID 00002405071
// This class needs a main method and two more methods.
//In main:
// create an array capable of holding six Book objects.
// use the parameterized constructor to specify the data in the first four elements of this array
// use the no-arg constructor to create the two remaining books in the array.  
// process the array with a foreach loop to display the array at this point.
// call the finishArray() method with the array as the only argument.
// call the reduceBooks() method with the array as the sole argument.
// repeat the code needed by Step 4 above.
// display the most expensive book after the discounts.
//In finishArray():
// this is a void method.
// use the setter methods to specify the data in all fields of the last two books in the array.
//In reduceBooks():
// is method returns a Book instance.
// use a loop (any type) to reduce the price of every book in the array by 40%.
// determine the most expensive book after the discounts and return this book to main.

public class TestBook {

	public static void main(String[] args) {
		// Create an array of 6 book objects
		Book[] books = new Book[6];
		// use the parameterized constructor to create 4 book objects
		Book jonathanLivingstonSeagull = new Book("Jonathan Livingston Seagull", "Richard Bach", 144, 19.49);
		Book biplane = new Book("Biplane", "Richard Bach", 176, 9.82);
		Book illusions = new Book("Illusions: The adventures of a Reluctant Messiah", "Richard Bach", 192, 7.99);
		Book theBridgeAcrossFroever = new Book("The Bridge Across Forever", "Richard Bach", 400, 14.99);
		// use the no argument constructor to create the last 2 books.
		Book book5 = new Book();
		Book book6 = new Book();
		// assign the books to the array.
		books[0] = jonathanLivingstonSeagull;
		books[1] = biplane;
		books[2] = illusions;
		books[3] = theBridgeAcrossFroever;
		books[4] = book5;
		books[5] = book6;
		// foreach loop to print out the books in the array
		for (Book n: books)
			System.out.println(n);
		System.out.println("");
		// call finishArray in order to add the final 2 books for the array, passing it the books array
		finishArray(books);
		// call reduceBooks method in order to discount the books
		reduceBooks(books);
		System.out.println("Books after completing the library and a 40% discount:");
		// print the books using a foreach loop again, this time using the finished array.
		for (Book n: books)
			System.out.println(n);
		System.out.println("");
		System.out.println("Here is the most expensive book after discount: ");
		// create a variable to hold the most expensive book and assign it to the first book
		// in the array
		Book expensive = books[0];
		// for loop to pass through the prices of the books after discount, starting at the index 1
		// as we have assigned the initial value to index 0 for the most expensive
		for (int i = 1; i < books.length; i++) {
			// if the current books price is higher than the book price at index 0, assign the most new index to expensive
		    if(books[0].getPrice() < books[i].getPrice()) {
		        expensive = books[i];
		    }
		}
		// print the most expensive book
		System.out.println(expensive);
		// print the size of the library
		System.out.println("Size of library: " + Book.numBooks);
	}
	// method to finish the array. assigning using the setter methods this time.
	public static void finishArray(Book[] books) {
		books[4].setTitle("Fear and Loathing on the Campaign Trail");
		books[4].setAuthor("Hunter S. Thompson");
		books[4].setPages(506);
		books[4].setPrice(8.25);
		
		books[5].setTitle("The Rum Diary");
		books[5].setAuthor("Hunter S. Thompson");
		books[5].setPages(213);
		books[5].setPrice(12.99);
	}
	// method to reduce the price returning the array after discounting.
	public static Book reduceBooks(Book[] books) {	
		Book discounted = books[0];
		// use the getter for price for the current index
		discounted.getPrice();
		// foreach loop to loop through the array
		for(Book n: books) {
			// set the price of the array after applying a 40% discount, using the getPrice method*discount 
			n.setPrice(n.getPrice() * .6);
		}
		//return the discounted array
		return discounted;
	}
}