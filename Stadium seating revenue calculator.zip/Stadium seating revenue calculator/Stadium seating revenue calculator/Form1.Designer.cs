﻿namespace Stadium_seating_revenue_calculator
{
    partial class stadiumSeatingCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ticketsSoldGroupBox = new System.Windows.Forms.GroupBox();
            this.classClabel = new System.Windows.Forms.Label();
            this.classBlabel = new System.Windows.Forms.Label();
            this.classAlabel = new System.Windows.Forms.Label();
            this.classCticketsSold = new System.Windows.Forms.TextBox();
            this.classBticketsSold = new System.Windows.Forms.TextBox();
            this.classAticketsSold = new System.Windows.Forms.TextBox();
            this.ticketInputForm = new System.Windows.Forms.Label();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.totalRevenueOutputLabel = new System.Windows.Forms.Label();
            this.classCrevenueOutputLabel = new System.Windows.Forms.Label();
            this.classBrevenueOutputLabel = new System.Windows.Forms.Label();
            this.classArevenueOutputLabel = new System.Windows.Forms.Label();
            this.totalRevenueLabel = new System.Windows.Forms.Label();
            this.classCrevenueLabel = new System.Windows.Forms.Label();
            this.classBrevenueLabel = new System.Windows.Forms.Label();
            this.classArevenueLabel = new System.Windows.Forms.Label();
            this.calculateRevenueButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.ticketsSoldGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // ticketsSoldGroupBox
            // 
            this.ticketsSoldGroupBox.Controls.Add(this.classClabel);
            this.ticketsSoldGroupBox.Controls.Add(this.classBlabel);
            this.ticketsSoldGroupBox.Controls.Add(this.classAlabel);
            this.ticketsSoldGroupBox.Controls.Add(this.classCticketsSold);
            this.ticketsSoldGroupBox.Controls.Add(this.classBticketsSold);
            this.ticketsSoldGroupBox.Controls.Add(this.classAticketsSold);
            this.ticketsSoldGroupBox.Controls.Add(this.ticketInputForm);
            this.ticketsSoldGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketsSoldGroupBox.Location = new System.Drawing.Point(12, 32);
            this.ticketsSoldGroupBox.Name = "ticketsSoldGroupBox";
            this.ticketsSoldGroupBox.Size = new System.Drawing.Size(305, 191);
            this.ticketsSoldGroupBox.TabIndex = 0;
            this.ticketsSoldGroupBox.TabStop = false;
            this.ticketsSoldGroupBox.Text = "Tickets Sold";
            // 
            // classClabel
            // 
            this.classClabel.AutoSize = true;
            this.classClabel.Location = new System.Drawing.Point(21, 142);
            this.classClabel.Name = "classClabel";
            this.classClabel.Size = new System.Drawing.Size(57, 16);
            this.classClabel.TabIndex = 6;
            this.classClabel.Text = "Class C:";
            this.classClabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classBlabel
            // 
            this.classBlabel.AutoSize = true;
            this.classBlabel.Location = new System.Drawing.Point(21, 114);
            this.classBlabel.Name = "classBlabel";
            this.classBlabel.Size = new System.Drawing.Size(57, 16);
            this.classBlabel.TabIndex = 5;
            this.classBlabel.Text = "Class B:";
            this.classBlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classAlabel
            // 
            this.classAlabel.AutoSize = true;
            this.classAlabel.Location = new System.Drawing.Point(21, 86);
            this.classAlabel.Name = "classAlabel";
            this.classAlabel.Size = new System.Drawing.Size(57, 16);
            this.classAlabel.TabIndex = 4;
            this.classAlabel.Text = "Class A:";
            this.classAlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classCticketsSold
            // 
            this.classCticketsSold.Location = new System.Drawing.Point(84, 139);
            this.classCticketsSold.Name = "classCticketsSold";
            this.classCticketsSold.Size = new System.Drawing.Size(138, 22);
            this.classCticketsSold.TabIndex = 3;
            this.classCticketsSold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // classBticketsSold
            // 
            this.classBticketsSold.Location = new System.Drawing.Point(84, 111);
            this.classBticketsSold.Name = "classBticketsSold";
            this.classBticketsSold.Size = new System.Drawing.Size(138, 22);
            this.classBticketsSold.TabIndex = 2;
            this.classBticketsSold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // classAticketsSold
            // 
            this.classAticketsSold.Location = new System.Drawing.Point(84, 83);
            this.classAticketsSold.Name = "classAticketsSold";
            this.classAticketsSold.Size = new System.Drawing.Size(138, 22);
            this.classAticketsSold.TabIndex = 1;
            this.classAticketsSold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.classAticketsSold.TextChanged += new System.EventHandler(this.classAticketsSold_TextChanged);
            // 
            // ticketInputForm
            // 
            this.ticketInputForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ticketInputForm.Location = new System.Drawing.Point(21, 28);
            this.ticketInputForm.Name = "ticketInputForm";
            this.ticketInputForm.Size = new System.Drawing.Size(201, 38);
            this.ticketInputForm.TabIndex = 0;
            this.ticketInputForm.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.totalRevenueOutputLabel);
            this.outputGroupBox.Controls.Add(this.classCrevenueOutputLabel);
            this.outputGroupBox.Controls.Add(this.classBrevenueOutputLabel);
            this.outputGroupBox.Controls.Add(this.classArevenueOutputLabel);
            this.outputGroupBox.Controls.Add(this.totalRevenueLabel);
            this.outputGroupBox.Controls.Add(this.classCrevenueLabel);
            this.outputGroupBox.Controls.Add(this.classBrevenueLabel);
            this.outputGroupBox.Controls.Add(this.classArevenueLabel);
            this.outputGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputGroupBox.Location = new System.Drawing.Point(323, 32);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(309, 191);
            this.outputGroupBox.TabIndex = 1;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Revenue Generated";
            // 
            // totalRevenueOutputLabel
            // 
            this.totalRevenueOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalRevenueOutputLabel.Location = new System.Drawing.Point(88, 135);
            this.totalRevenueOutputLabel.Name = "totalRevenueOutputLabel";
            this.totalRevenueOutputLabel.Size = new System.Drawing.Size(136, 24);
            this.totalRevenueOutputLabel.TabIndex = 8;
            this.totalRevenueOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classCrevenueOutputLabel
            // 
            this.classCrevenueOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classCrevenueOutputLabel.Location = new System.Drawing.Point(88, 98);
            this.classCrevenueOutputLabel.Name = "classCrevenueOutputLabel";
            this.classCrevenueOutputLabel.Size = new System.Drawing.Size(136, 24);
            this.classCrevenueOutputLabel.TabIndex = 7;
            this.classCrevenueOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classBrevenueOutputLabel
            // 
            this.classBrevenueOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classBrevenueOutputLabel.Location = new System.Drawing.Point(88, 60);
            this.classBrevenueOutputLabel.Name = "classBrevenueOutputLabel";
            this.classBrevenueOutputLabel.Size = new System.Drawing.Size(136, 24);
            this.classBrevenueOutputLabel.TabIndex = 6;
            this.classBrevenueOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // classArevenueOutputLabel
            // 
            this.classArevenueOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.classArevenueOutputLabel.Location = new System.Drawing.Point(88, 24);
            this.classArevenueOutputLabel.Name = "classArevenueOutputLabel";
            this.classArevenueOutputLabel.Size = new System.Drawing.Size(136, 24);
            this.classArevenueOutputLabel.TabIndex = 5;
            this.classArevenueOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalRevenueLabel
            // 
            this.totalRevenueLabel.AutoSize = true;
            this.totalRevenueLabel.Location = new System.Drawing.Point(40, 139);
            this.totalRevenueLabel.Name = "totalRevenueLabel";
            this.totalRevenueLabel.Size = new System.Drawing.Size(42, 16);
            this.totalRevenueLabel.TabIndex = 4;
            this.totalRevenueLabel.Text = "Total:";
            // 
            // classCrevenueLabel
            // 
            this.classCrevenueLabel.AutoSize = true;
            this.classCrevenueLabel.Location = new System.Drawing.Point(25, 102);
            this.classCrevenueLabel.Name = "classCrevenueLabel";
            this.classCrevenueLabel.Size = new System.Drawing.Size(57, 16);
            this.classCrevenueLabel.TabIndex = 3;
            this.classCrevenueLabel.Text = "Class C:";
            // 
            // classBrevenueLabel
            // 
            this.classBrevenueLabel.AutoSize = true;
            this.classBrevenueLabel.Location = new System.Drawing.Point(25, 64);
            this.classBrevenueLabel.Name = "classBrevenueLabel";
            this.classBrevenueLabel.Size = new System.Drawing.Size(57, 16);
            this.classBrevenueLabel.TabIndex = 2;
            this.classBrevenueLabel.Text = "Class B:";
            // 
            // classArevenueLabel
            // 
            this.classArevenueLabel.AutoSize = true;
            this.classArevenueLabel.Location = new System.Drawing.Point(25, 28);
            this.classArevenueLabel.Name = "classArevenueLabel";
            this.classArevenueLabel.Size = new System.Drawing.Size(57, 16);
            this.classArevenueLabel.TabIndex = 1;
            this.classArevenueLabel.Text = "Class A:";
            // 
            // calculateRevenueButton
            // 
            this.calculateRevenueButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateRevenueButton.Location = new System.Drawing.Point(96, 256);
            this.calculateRevenueButton.Name = "calculateRevenueButton";
            this.calculateRevenueButton.Size = new System.Drawing.Size(128, 78);
            this.calculateRevenueButton.TabIndex = 2;
            this.calculateRevenueButton.Text = "Calculate Revenue";
            this.calculateRevenueButton.UseVisualStyleBackColor = true;
            this.calculateRevenueButton.Click += new System.EventHandler(this.calculateRevenueButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(261, 256);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(128, 78);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(419, 256);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(128, 78);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // stadiumSeatingCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 361);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateRevenueButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.ticketsSoldGroupBox);
            this.Name = "stadiumSeatingCalculator";
            this.Text = "Stadium Seating";
            this.ticketsSoldGroupBox.ResumeLayout(false);
            this.ticketsSoldGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ticketsSoldGroupBox;
        private System.Windows.Forms.Label ticketInputForm;
        private System.Windows.Forms.TextBox classCticketsSold;
        private System.Windows.Forms.TextBox classBticketsSold;
        private System.Windows.Forms.TextBox classAticketsSold;
        private System.Windows.Forms.Label classClabel;
        private System.Windows.Forms.Label classBlabel;
        private System.Windows.Forms.Label classAlabel;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label totalRevenueOutputLabel;
        private System.Windows.Forms.Label classCrevenueOutputLabel;
        private System.Windows.Forms.Label classBrevenueOutputLabel;
        private System.Windows.Forms.Label classArevenueOutputLabel;
        private System.Windows.Forms.Label totalRevenueLabel;
        private System.Windows.Forms.Label classCrevenueLabel;
        private System.Windows.Forms.Label classBrevenueLabel;
        private System.Windows.Forms.Label classArevenueLabel;
        private System.Windows.Forms.Button calculateRevenueButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

