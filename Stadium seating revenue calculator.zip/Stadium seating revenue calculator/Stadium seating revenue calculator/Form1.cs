﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stadium_seating_revenue_calculator
{
    public partial class stadiumSeatingCalculator : Form
    {
        const int class_A_Cost = 15;
        const int class_B_Cost = 12;
        const int class_C_Cost = 9;
        int class_A_Sales;
        int class_B_Sales;
        int class_C_Sales;
        int class_A_Revenue;
        int class_B_Revenue;
        int class_C_Revenue;
        int total_Revenue;
        public stadiumSeatingCalculator()
        {
            InitializeComponent();
        }

        private void classAticketsSold_TextChanged(object sender, EventArgs e)
        {

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            classAticketsSold.Text = "";
            classBticketsSold.Text = "";
            classCticketsSold.Text = "";
            classArevenueOutputLabel.Text = "";
            classBrevenueOutputLabel.Text = "";
            classCrevenueOutputLabel.Text = "";
            totalRevenueOutputLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateRevenueButton_Click(object sender, EventArgs e)
        {
            try
            {
                class_A_Sales = int.Parse(classAticketsSold.Text);
                class_B_Sales = int.Parse(classBticketsSold.Text);
                class_C_Sales = int.Parse(classCticketsSold.Text);
                class_A_Revenue = class_A_Sales * class_A_Cost;
                class_B_Revenue = class_B_Sales * class_B_Cost;
                class_C_Revenue = class_C_Sales * class_C_Cost;
                total_Revenue = class_A_Revenue + class_B_Revenue + class_C_Revenue;

                classArevenueOutputLabel.Text = class_A_Revenue.ToString("c");
                classBrevenueOutputLabel.Text = class_B_Revenue.ToString("c");
                classCrevenueOutputLabel.Text = class_C_Revenue.ToString("c");
                totalRevenueOutputLabel.Text = total_Revenue.ToString("c");
            }
            catch
            {
                MessageBox.Show("Please enter a valid number of tickets sold");
            }
        }
    }
}
