package clements1and2;
import java.util.Scanner;

public class WeightConverter {

	public static void main(String[] args) {
		// Arthur Clements, SPC ID 00002405071
		// Program accepting user input to convert an entered weight in kg to lbs.
		
		// create a container for input from user to be stored, titled input
		Scanner input = new Scanner(System.in);
		// prompt user for input
		System.out.println("Enter a weight in Kg to convert to Lbs = ");
		// declare a variable titled kgWeight and assign the input from the user to it.
		double kgWeight = input.nextDouble();
		// convert kg to lbs and assign it to a variable lbWeight. conversion is kbWeight*2.20462
		double lbWeight = kgWeight * 2.20462;
		System.out.println("Your weight in lb is = " + lbWeight);
	}

}
