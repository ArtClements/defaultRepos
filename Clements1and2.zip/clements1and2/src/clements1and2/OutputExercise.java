package clements1and2;

public class OutputExercise {
	public static void main(String[] args) {
		// Arthur Clements, SPC ID 00002405071
		// Program outputting standard data with no user input
		System.out.println("Arthur Allen Clements");
		System.out.println("Java was developed by a team led by James Gosling");
		System.out.println("Java rocks!");
		System.out.print("(12.5 + 5.5 / 3) / (6.25 * 6 - 5.0) = ");
		System.out.println((12.5 + 5.5 / 3) / (6.25 * 6 - 5.0));
	}
}
