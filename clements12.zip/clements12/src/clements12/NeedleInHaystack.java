package clements12;
// Arthur Clements, SPC ID 00002405071
// Create a Java program with a method that searches an integer array for a specified integer value 
// (see help with starting the method header below). If the array contains the specified integer, 
// the method should return its index in the array. If not, the method should throw an Exception stating 
// "Element not found in array" and end gracefully. Test the method in main with an array that you make 
// and with user input for the "needle". I also wrapped it in a try/catch statement in order to verify
// user inputs an int and not another 

import java.util.*;
public class NeedleInHaystack {
	// returnIndex method which takes 2 arguments, an array of ints labeled haystack and the int needle
	public static int returnIndex(int[ ] haystack, int needle) {
		// for loop to step through the array
		for (int n = 0; n < haystack.length; n++) {
			// if the current index is equal to the int the user guessed
	        if (haystack[n] == needle)
	        	// return the array
	            return n;
	    }
		// throw exception if the element is not found in the array.
	    throw new NoSuchElementException("Element not found in array");
	}
	
	public static void main(String[] args) {
		// create scanner to hold user input
		Scanner input = new Scanner(System.in);
		// create array of integers, haystack, to store 50 integers
		int[] haystack = new int[50];
		// fill array with 50 unique integers between 1 and 100(inclusive) validate if the
		// number matches one in the array and if so replace with a new random
		for (int i = 0; i < haystack.length; i++) {
			haystack[i] = (int)(Math.random()*101);
			for (int h = 0; h < i; h++) {
				if (haystack[i] == haystack[h]) {
					haystack[h] = (int)(Math.random()*101);
					}
				}
			}
		// boolean to test if user input is valid (is an integer and not double)
		boolean verifyInt = true;
		// prompt user for input
		System.out.println("We have a group of 50 integers, ranging from 1-100 with no duplicates.");
		// do while loop so that the system will ask the user for input to start
		do {
			// try/ catch statement to verify if the user inputs an integer.
			try {
				// prompt the user for input
				System.out.println("Please enter an integer that you would like to guess is in the list: ");
				// create integer needle to hold the users guess
				int needle = input.nextInt();
				// try/catch statement to verify if the users guess is in the array
				try {
					// create variable to hold the index, returned by returnIndex, passing it the array and guess
					int indexOfNeedle = returnIndex(haystack, needle);
					// output the users number and index in the array
					System.out.println("The index of " + needle +" is "+ indexOfNeedle);
					// display the array to ensure no funny business
					System.out.println("The haystack includes:");
					// foreach loop to output the haystack so user can validate they weren't swindled
					for(int n: haystack) {
						System.out.print(n + " ");
						}
					}
				// catch of inner try/catch if number not in the haystack
				catch(NoSuchElementException ex){
					System.out.println(ex.getMessage());
					}
				// update verifyInt to false so the loop terminates
				verifyInt = false;
				input.close();
				}
			// catch for outer try/catch to be thrown if the user does not enter an integer.
			catch(InputMismatchException ex){
				System.out.println("Sorry, your input was not valid.");
				// clear the input so can be re entered. not clearing would cause a loop of the same input and same error
				input.nextLine();
				}
			}
		// perform the loop while verifyInt = true
		while(verifyInt);
		}
	}