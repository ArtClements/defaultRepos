package clements12;
// Arthur Clements, SPC ID 00002405071
// Write a program in a single file that:
// Main: Creates 10 random doubles, all between 1 and 11,
// Calls a method that writes 10 random doubles to a text file, one number per line.
// Calls a method that reads the text file and displays all the doubles and their sum accurate to two decimal places.

import java.io.*;
import java.util.*;
public class OutputToFile {
	// writeFile method that accepts the array we create in main as an argument
	public static void writeFile(double[] numbers) throws IOException {
		// create new file "Random Doubles"
		File file = new File("Random Doubles.txt");
		// create PrintWriter object
		java.io.PrintWriter output = new java.io.PrintWriter(file);
		// loop to step through the array elements
		for(double n: numbers) {
			// write the element to the file
			output.println(n);
		}
		// close file
		output.close();
	}
	// readFile method in order to read the info from the file
	public static void readFile() throws FileNotFoundException{
		// create an instance for the file
		File file = new File("Random Doubles.txt");
		// create a new scanner for the file
		Scanner input = new Scanner(file);
		// create double to hold the sum of all digits
		double sum = 0;
		// while there is input
		while(input.hasNext()) {
			// assign the next double in the file to variable randomDouble
			double randomDouble = Math.round(input.nextDouble()*100d)/100d;
			// increment sum by randomDouble
			sum += randomDouble;
			// print the current value of randomDouble with 2 decimals
			System.out.printf("%.2f\r", randomDouble);
		}
		// print sum using 2 decimals.
		System.out.printf("%.2f", sum);
		// close file
		input.close();
	}

	public static void main(String[] args) throws IOException{
		// create an array of doubles and set it to hold 10 elements
		double[] outputNumbers = new double[10];
		// for loop to fill the array with unique doubles between 1 and 11
		for (int i = 0; i < outputNumbers.length; i++) {
			outputNumbers[i] = (double)1+(Math.random()*11);
			for (int h = 0; h < i; h++) {
				if (outputNumbers[i] == outputNumbers[h]) {
					outputNumbers[h] = (double)1+(Math.random()*11);
					}
				}
			}
		// call the 2 methods to write, then read the file
		writeFile(outputNumbers);
		readFile();
		}
	}