﻿namespace distance_converter
{
    partial class distanceConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterDistanceLabel = new System.Windows.Forms.Label();
            this.distanceEntered = new System.Windows.Forms.TextBox();
            this.fromGroupBox = new System.Windows.Forms.GroupBox();
            this.distanceFromList = new System.Windows.Forms.ListBox();
            this.toGroupBox = new System.Windows.Forms.GroupBox();
            this.distanceToList = new System.Windows.Forms.ListBox();
            this.convertedDistanceLabel = new System.Windows.Forms.Label();
            this.distanceDisplayLabel = new System.Windows.Forms.Label();
            this.convertButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.fromGroupBox.SuspendLayout();
            this.toGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // enterDistanceLabel
            // 
            this.enterDistanceLabel.AutoSize = true;
            this.enterDistanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterDistanceLabel.Location = new System.Drawing.Point(12, 23);
            this.enterDistanceLabel.Name = "enterDistanceLabel";
            this.enterDistanceLabel.Size = new System.Drawing.Size(168, 16);
            this.enterDistanceLabel.TabIndex = 0;
            this.enterDistanceLabel.Text = "Enter a distance to convert:";
            // 
            // distanceEntered
            // 
            this.distanceEntered.Location = new System.Drawing.Point(186, 23);
            this.distanceEntered.Name = "distanceEntered";
            this.distanceEntered.Size = new System.Drawing.Size(130, 20);
            this.distanceEntered.TabIndex = 1;
            // 
            // fromGroupBox
            // 
            this.fromGroupBox.Controls.Add(this.distanceFromList);
            this.fromGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromGroupBox.Location = new System.Drawing.Point(12, 58);
            this.fromGroupBox.Name = "fromGroupBox";
            this.fromGroupBox.Size = new System.Drawing.Size(156, 117);
            this.fromGroupBox.TabIndex = 2;
            this.fromGroupBox.TabStop = false;
            this.fromGroupBox.Text = "From:";
            // 
            // distanceFromList
            // 
            this.distanceFromList.FormattingEnabled = true;
            this.distanceFromList.ItemHeight = 16;
            this.distanceFromList.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.distanceFromList.Location = new System.Drawing.Point(21, 35);
            this.distanceFromList.Name = "distanceFromList";
            this.distanceFromList.Size = new System.Drawing.Size(116, 52);
            this.distanceFromList.TabIndex = 0;
            // 
            // toGroupBox
            // 
            this.toGroupBox.Controls.Add(this.distanceToList);
            this.toGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toGroupBox.Location = new System.Drawing.Point(204, 58);
            this.toGroupBox.Name = "toGroupBox";
            this.toGroupBox.Size = new System.Drawing.Size(156, 117);
            this.toGroupBox.TabIndex = 3;
            this.toGroupBox.TabStop = false;
            this.toGroupBox.Text = "To:";
            // 
            // distanceToList
            // 
            this.distanceToList.FormattingEnabled = true;
            this.distanceToList.ItemHeight = 16;
            this.distanceToList.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.distanceToList.Location = new System.Drawing.Point(20, 32);
            this.distanceToList.Name = "distanceToList";
            this.distanceToList.Size = new System.Drawing.Size(116, 52);
            this.distanceToList.TabIndex = 1;
            // 
            // convertedDistanceLabel
            // 
            this.convertedDistanceLabel.AutoSize = true;
            this.convertedDistanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertedDistanceLabel.Location = new System.Drawing.Point(39, 189);
            this.convertedDistanceLabel.Name = "convertedDistanceLabel";
            this.convertedDistanceLabel.Size = new System.Drawing.Size(129, 16);
            this.convertedDistanceLabel.TabIndex = 4;
            this.convertedDistanceLabel.Text = "Converted Distance:";
            // 
            // distanceDisplayLabel
            // 
            this.distanceDisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.distanceDisplayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.distanceDisplayLabel.Location = new System.Drawing.Point(174, 187);
            this.distanceDisplayLabel.Name = "distanceDisplayLabel";
            this.distanceDisplayLabel.Size = new System.Drawing.Size(130, 20);
            this.distanceDisplayLabel.TabIndex = 5;
            this.distanceDisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(15, 228);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(112, 39);
            this.convertButton.TabIndex = 6;
            this.convertButton.Text = "Convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(248, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 39);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(142, 227);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(91, 38);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // distanceConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 287);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.distanceDisplayLabel);
            this.Controls.Add(this.convertedDistanceLabel);
            this.Controls.Add(this.toGroupBox);
            this.Controls.Add(this.fromGroupBox);
            this.Controls.Add(this.distanceEntered);
            this.Controls.Add(this.enterDistanceLabel);
            this.Name = "distanceConverter";
            this.Text = "Distance Converter";
            this.fromGroupBox.ResumeLayout(false);
            this.toGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterDistanceLabel;
        private System.Windows.Forms.TextBox distanceEntered;
        private System.Windows.Forms.GroupBox fromGroupBox;
        private System.Windows.Forms.ListBox distanceFromList;
        private System.Windows.Forms.GroupBox toGroupBox;
        private System.Windows.Forms.ListBox distanceToList;
        private System.Windows.Forms.Label convertedDistanceLabel;
        private System.Windows.Forms.Label distanceDisplayLabel;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

