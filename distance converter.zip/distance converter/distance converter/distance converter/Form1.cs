﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace distance_converter
{
    public partial class distanceConverter : Form
    {
        const double inchesInFoot = 12.0;
        const double inchesInYard = 36.0;
        const double feetInYard = 3.0;
        double numericDistance;
        double convertedDistance;
        string convertFrom;
        string convertTo;

        public distanceConverter()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                numericDistance = double.Parse(distanceEntered.Text);
                if (distanceFromList.SelectedIndex != -1)
                {
                    convertFrom = distanceFromList.SelectedItem.ToString();
                    convertTo = distanceToList.SelectedItem.ToString();
                    switch(convertFrom)
                    {
                        case "Inches":
                            switch (convertTo)
                            {
                                case "Inches":
                                    MessageBox.Show("Please select a valid option to convert to");
                                    break;
                                case "Feet":
                                    convertedDistance = numericDistance / inchesInFoot;
                                    break;
                                case "Yards":
                                    convertedDistance = numericDistance / inchesInYard;
                                    break;
                            }
                            break;
                        case "Feet":
                            switch(convertTo)
                            {
                                case "Inches":
                                    convertedDistance = numericDistance * inchesInFoot;
                                    break;
                                case "Feet":
                                    MessageBox.Show("Please select a valid option to convert to");
                                    break;
                                case "Yards":
                                    convertedDistance = numericDistance / feetInYard;
                                    break;
                            }
                            break;
                        case "Yards":
                            switch(convertTo)
                            {
                                case "Inches":
                                    convertedDistance = numericDistance * inchesInYard ;   
                                    break;
                                case "Feet":
                                    convertedDistance = numericDistance * feetInYard;
                                    break;
                                case "Yards":
                                    MessageBox.Show("Please select a valid option to convert to");
                                    break;
                            }
                            break;
                    }
                }
                else
                {
                MessageBox.Show("Please select a distance to convert");
                }
            }
            catch
            {
                MessageBox.Show("Please enter a valid distance");
            }
            distanceDisplayLabel.Text = convertedDistance.ToString("n2");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            distanceDisplayLabel.Text = " ";
            distanceEntered.Text = " ";
        }
    }
}
