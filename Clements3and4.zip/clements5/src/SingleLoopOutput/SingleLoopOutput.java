package SingleLoopOutput;
// Arthur Clements, SPC ID 00002405071
// Create a program that counts backwards from 300 to 200 (inclusive) and checks to see
// if the dividend is divisible by either 11 or 13, but not both. Print out the numbers
// found with 8 character spacing, in 5 columns. Finally display the total numbers found
// that were divisible by 11 or 13, and display the total of those numbers. All of this 
// should be done using only one loop.
public class SingleLoopOutput {

	public static void main(String[] args) {
		// create containers to hold the amount of numbers found, the sum of the individual numbers,
		// and the amount of columns that we want to have
		int numbersFound = 0;
		int sum = 0;
		int columns = 0;
		
		System.out.println("Lets check the numbers from 200 to 300 to see what is "
				+ "divisable\nby 11 or 13, but not both. Here are those numbers:");
		//cycle through the numbers starting at 300 and going down to 200, decrementing dividend after each iteration
		for (int dividend = 300; dividend >= 200; --dividend) {
			// check to see if the dividend provides no remainder if divided by 11 or 13, but not both. could also use !=
			if((dividend % 11 == 0)^(dividend % 13 == 0)) {
				//check to see what column is at, and if it is 5, the max width we want, then print to a new line and reset column
				if (columns == 5) {
					System.out.println();
					columns = 0;
				}
				// if dividend is divisible by 11 or 13, increment numbersFound, add the dividend to sum, increment columns and print
				// the dividend with 8 character spacing. 
				numbersFound++;
				sum += dividend;
				columns++;
				System.out.printf("%-8d", dividend);
			}
		}
		//print the final value of sum and numbersFound.
		System.out.println("\nWe found " + numbersFound + " integers totaling " + sum);
	}

}
