package MultiplicationPractice;
import java.util.Scanner;
// Athur Clements, SPC ID 00002405071
// Write a program that deliberately contains an endless or infinite while loop.
// The loop should generate multiplication questions with single digit random integers.
// Users can answer the questions and get immediate feedback. After each question,
// the user should be able to stop the questions and get an overall result.

public class MultiplicationPractice {	
	
	public static void main(String[] args) {
		// create scanner to hold the users input on if they wish to continue
		// as well as variables for the numbers to multiply, the total that 
		// the user guesses, the total of questions asked, the amount of 
		// correct answers and to continue or not.	
	    Scanner input = new Scanner(System.in);
	    int num1;
	    int num2;
	    int result;
	    int total = 0;
	    int correct = 0;
	    char cont = 'Y';
	       
	    // create loop, where if continue(cont) is Y that it executes 
	    while(cont == 'Y'){
	    	//create random numbers to multiply
	    	num1 = (int)(Math.random()*10);
	        num2 = (int)(Math.random()*10);
	        System.out.print("What is " + num1 + " * " + num2 + " ? ");
	        // user input for their expected answer
	        result = input.nextInt(); 
	        // check to see if the result is correct
	        if(result == num1 * num2){
	        	// display correct
	        	System.out.println("Correct. Nice work!");
	        	// if correct increment correct
	            correct++;
	            }
	   	           else{
	   	        	   // if not correct display the correct answer.
	   	        	   System.out.println("Incorrect. The product is " + (num1 * num2));
	           }
	        // prompt user to continue or not
	        System.out.print("Want more questions y or n ? ");
	        //accept user input
	        cont = input.next().charAt(0);
	        // convert to upper case so that we can ensure that it is not canceled if case is incorrect.
	        // if y was entered and we set cont to Y, it would cancel. if Y is entered and we set cont to
	        // y, the program would exit. Setting it to upper ensures that errors can not occur.
	        cont = Character.toUpperCase(cont);
	        //add question that was just answered to the total number of questions asked.
	        total++;
	       }
	    // If the user opted out for more questions then display the correct answers and the total questions asked.
	    System.out.println("You scored " + correct + " out of " + total);
	}
}