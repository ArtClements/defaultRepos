package clements6;
// Athur Clements, SPC ID 00002405071
// create a program that analyzes an object falling for 10 seconds. it should contain main and two additional methods.
// One of the additional methods should return the distance an object falls in meters when passed the current second as
// an argument. The third method should convert meters to feet and return feet. The main method should use one loop to
// call the other methods and generate a table displaying the information formatted to 1 decimal place.

public class FallDistanceAndTime {
	// method to calculate meters, accepting fallTime as an argument
	private static double calculateMeters (int fallTime) {
		// variables to use in the calculation of the meters fallen
		double g = 9.8;
		double half = 0.5;
		// calculate meters
		double meters = (half*g*Math.pow(fallTime, 2));
		// return meters
		return meters;
	}
	// method to convert meters to feet. accept meters as an argument
	public static double metersToFeet(double meters) {
		//calculate and return feet
		double feet = meters * 3.28084;
		return feet;
	}	
	public static void main(String[] args) {
		// print the header
		System.out.printf("%-10s%-10s%-10s\r", "Sec","Meters", "Feet");
		// loop to iterate through the different fall times
		for (int fallTime = 1; fallTime <= 10; fallTime++) {
			// declare meters and assign the returned value by calling the calculate to meters method, passing the current fallTime
			double meters = calculateMeters(fallTime);
			// declare feet and assign the returned value by calling the metersToFeet method, passing the value of meters
			double feet = metersToFeet(meters);
			//print out the current time and the meters and feet results for the given time, making sure to keep decimal placement
			System.out.printf("%-8d%8.1f%8.1f\r" , fallTime, meters , feet);
		}
	}
}