package clements6;
// Athur Clements, SPC ID 00002405071
// Write a program that simulates tossing a coin. Prompt the user for how many times to toss the coin. 
// Code a method with no parameters that randomly returns either the string "heads" or "tails". Call 
// this method in main as many times as requested and report the results.

import java.util.Scanner;

public class CoinFlip {
	// Create method "flip" to simulate the flip, it takes no parameters.
	public static String flip() {
		// create variable for the result and set it to null to hold the string result
		String result = null;
		// create a random int 0 or 1 and store it to flip to assign a numerical result
		int flip = (int)(Math.random()*2);
		// create if statement to assign a result name to the number, if 0, heads
		if (flip == 0) {
			result = "heads";
		}
		// if 1, tails
		else {
			result = "tails";
		}
		//return the string result
		return result;
	}

	public static void main(String[] args) {
		// create variables to hold the total amount of heads and tails counted as well
		// as a String variable to hold what will be returned from the flip method.
		int headsCount = 0;
		int tailsCount = 0;
		String result;
		// Create scanner and prompt user for the amount of times they wish to flip a coin
		Scanner input = new Scanner(System.in);
		System.out.print("How many times would you like to flip a coin: ");
		// declare an int to hold the users input, flips.
		int flips = input.nextInt();
		// loop from 1 - users input, incrementing after each iteration
		for (int count = 1; count <= flips; count++) {
			// call the flip method and store to result
			result = flip();
			// if statement to increment either headCount
			if(result == "heads") {
				headsCount++;
				}
			// or increment tailsCount depending on what the method returns
			else {
				tailsCount++;
				}
		}
		//output the total number of flips and the total number of heads/tails.
		System.out.println("We flipped a coin " + flips + " times");
		System.out.println("We flipped a total of " + headsCount + " heads and " + tailsCount + " tails.");
	}
}